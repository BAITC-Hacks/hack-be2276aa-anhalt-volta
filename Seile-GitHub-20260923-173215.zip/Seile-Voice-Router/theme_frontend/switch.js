/* Streamlit 1.64 adapter. Use its native palette engine (including portal menus),
 * not React internals or process-global Python config. Keep the DOM seam here. */
export default function mountThemeSwitch({data = {}} = {}) {
  // Streamlit re-invokes v2 JS on theme/data changes, but only cleans up on unmount.
  // Reuse one controller: a native theme change must not start a second switch.
  if (window.__soileThemeController) return window.__soileThemeController.cleanup;
  const root = document.documentElement;
  const key = 'soile.theme.v1';
  const valid = value => value === 'light' || value === 'dark';
  const read = () => { try { const value = localStorage.getItem(key); return valid(value) ? value : 'dark'; } catch { return 'dark'; } };
  const write = value => { try { localStorage.setItem(key, value); } catch { /* Private browsing: session still works. */ } };
  const selector = value => `[data-testid="stMainMenuItem-theme-${value === 'light' ? 'Light' : 'Dark'}"]`;
  const menu = () => document.querySelector('[data-testid="stMainMenuButton"]');
  let disposed = false, busy = false, animationTimer, pollTimer, desired = read();
  root.dataset.soileTheme = desired;
  const button = document.createElement('button');
  button.id = 'soile-theme-toggle'; button.type = 'button';
  const icon = document.createElement('span');
  icon.setAttribute('aria-hidden', 'true'); button.append(icon);
  document.getElementById(button.id)?.remove();
  document.body.append(button);
  // The markup is packaged with this application, never supplied by a model/user.
  const ambient = document.createElement('div');
  ambient.id = 'soile-ambient'; ambient.setAttribute('aria-hidden', 'true');
  ambient.setAttribute('inert', ''); ambient.innerHTML = data.ambient || '';
  document.querySelector('[data-testid="stMain"]')?.append(ambient);
  function visibility() {
    if (document.hidden) root.dataset.soilePageHidden = 'true';
    else delete root.dataset.soilePageHidden;
  }
  document.addEventListener('visibilitychange', visibility); visibility();
  function animateLighting() {
    if (!root.dataset.soileThemeReady) return;
    root.dataset.soileAnimate = 'true';
    clearTimeout(animationTimer);
    animationTimer = setTimeout(() => delete root.dataset.soileAnimate, 720);
  }
  function dock() {
    const container = menu()?.closest?.('[data-testid="stMainMenu"]');
    if (container?.parentElement) {
      container.parentElement.insertBefore(button, container);
      button.setAttribute('data-docked', 'true');
    }
  }

  function display(value) {
    root.dataset.soileTheme = value;
    const label = value === 'dark' ? 'Включить светлую тему' : 'Включить тёмную тему';
    icon.textContent = value === 'dark' ? '☾' : '☀';
    button.setAttribute('aria-label', label); button.title = label;
    root.dataset.soileThemeReady = 'true';
  }
  function nativePreference() {
    // Streamlit persists its native selection before paint on the next visit.
    // Read-only: do not inject a custom serialized framework theme.
    try { return JSON.parse(localStorage.getItem(`stActiveTheme-${location.pathname}-v2`))?.toLowerCase(); }
    catch { return null; }
  }
  const waitFor = predicate => new Promise(resolve => {
    const deadline = performance.now() + 1800;
    function poll() {
      if (disposed) { resolve(null); return; }
      const result = predicate();
      if (result || performance.now() > deadline) { resolve(result); return; }
      pollTimer = setTimeout(poll, 16);
    }
    poll();
  });
  async function apply(value, focus = false) {
    desired = valid(value) ? value : 'dark';
    if (busy || disposed) return;
    if (root.dataset.soileThemeReady && nativePreference() === desired) {
      dock(); display(desired); return;
    }
    busy = true; button.disabled = true;
    const target = desired;
    root.dataset.soileSwitching = 'true';
    animateLighting();
    try {
      const trigger = await waitFor(menu);
      if (!trigger) throw Error('Native theme menu unavailable');
      dock();
      if (trigger.getAttribute('aria-expanded') !== 'true') trigger.click();
      const option = await waitFor(() => document.querySelector(selector(target)));
      if (!option) throw Error('Native theme option unavailable');
      root.dataset.soileTheme = target;
      if (option.getAttribute('aria-checked') !== 'true') option.click();
      // React applies the native theme on its next paint. Keep the initial UI gated.
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      if (disposed) return;
      write(target); display(target);
    } catch (error) {
      if (disposed) return;
      display(valid(nativePreference()) ? nativePreference() : 'dark');
      button.title = 'Тема: используйте меню ⋮ → Light / Dark. ' + error.message;
    } finally {
      if (disposed) return;
      const trigger = menu();
      if (trigger?.getAttribute('aria-expanded') === 'true') trigger.click();
      delete root.dataset.soileSwitching;
      busy = false; button.disabled = false;
      if (focus && !disposed) button.focus();
      if (root.dataset.soileAnimate) animateLighting();
    }
    if (!disposed && desired !== target) apply(desired);
  }
  button.onclick = () => apply(root.dataset.soileTheme === 'dark' ? 'light' : 'dark', true);
  function storage(event) { if (event.key === key) apply(valid(event.newValue) ? event.newValue : 'dark'); }
  // Keep our icon and app-wide preference aligned if the native menu is used.
  function nativeClick(event) {
    if (busy) return;
    for (const value of ['light', 'dark']) {
      if (event.target.closest?.(selector(value))) {
        animateLighting(); desired = value; write(value); display(value);
      }
    }
  }
  window.addEventListener('storage', storage);
  document.addEventListener('click', nativeClick);
  const cleanup = () => {
    disposed = true; clearTimeout(animationTimer); clearTimeout(pollTimer);
    window.removeEventListener('storage', storage); document.removeEventListener('click', nativeClick);
    document.removeEventListener('visibilitychange', visibility); ambient.remove();
    delete root.dataset.soilePageHidden;
    delete root.dataset.soileSwitching; delete root.dataset.soileAnimate; button.remove();
    delete window.__soileThemeController;
  };
  window.__soileThemeController = {cleanup};
  apply(desired);
  return cleanup;
}
