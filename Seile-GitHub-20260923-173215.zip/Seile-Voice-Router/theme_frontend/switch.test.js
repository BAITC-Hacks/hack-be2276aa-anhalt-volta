const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const code = fs.readFileSync(path.join(__dirname, 'switch.js'), 'utf8').replace('export default ', '');
const flush = async () => { for (let i = 0; i < 12; i++) await new Promise(setImmediate); };

function browser({saved, native = 'Light', blocked = false} = {}) {
  const store = new Map();
  if (saved !== undefined) store.set('soile.theme.v1', saved);
  store.set('stActiveTheme-/-v2', JSON.stringify(native));
  const root = {dataset: {}}, listeners = {}, nodes = new Map();
  let selected = native.toLowerCase(), opened = false, menuClicks = 0;
  class Node {
    constructor() { this.attrs = {}; this.disabled = false; }
    setAttribute(k, v) { this.attrs[k] = v; }
    getAttribute(k) { return this.attrs[k]; }
    remove() { nodes.delete(this.id); }
    focus() { this.focused = true; }
    append(node) { (this.children ??= []).push(node); nodes.set(node.id, node); }
  }
  const trigger = {getAttribute: () => String(opened), click() {opened = !opened; menuClicks++;}};
  const options = Object.fromEntries(['light', 'dark'].map(value => [value, {
    getAttribute: () => String(selected === value), click() {
      selected = value;
      if (!blocked) store.set('stActiveTheme-/-v2', JSON.stringify(value === 'dark' ? 'Dark' : 'Light'));
    }
  }]));
  const document = {documentElement: root, body: {append(node) {nodes.set(node.id, node);}},
    hidden: false,
    createElement: () => new Node(), getElementById: id => nodes.get(id),
    addEventListener: (key, fn) => listeners[key] = fn,
    removeEventListener: key => delete listeners[key],
    querySelector(selector) {
      if (selector.includes('stMain"]')) return this.body;
      if (selector.includes('stMainMenuButton')) return trigger;
      if (!opened) return null;
      return options[selector.includes('theme-Light') ? 'light' : 'dark'];
    }};
  const sandbox = vm.createContext({document, location: {pathname: '/'},
    localStorage: {getItem(k) {if (blocked) throw Error('denied'); return store.get(k) ?? null;},
      setItem(k, v) {if (blocked) throw Error('denied'); store.set(k, v);}},
    window: {addEventListener: (k, f) => listeners[k] = f, removeEventListener: k => delete listeners[k]},
    performance, setTimeout, clearTimeout, requestAnimationFrame: fn => queueMicrotask(fn), console});
  vm.runInContext(code, sandbox);
  let cleanup = sandbox.mountThemeSwitch({data: {ambient: '<svg aria-hidden="true"></svg>'}});
  return {root, store, listeners, options, document, nodes, get button() {return nodes.get('soile-theme-toggle');},
    get selected() {return selected;}, get menuClicks() {return menuClicks;},
    unmount() {cleanup();}, reinvoke() {return sandbox.mountThemeSwitch();},
    remount() {cleanup(); cleanup = sandbox.mountThemeSwitch();}};
}

test('first visit is dark even on a light OS; one click switches and persists', async () => {
  const b = browser(); await flush();
  assert.equal(b.selected, 'dark'); assert.equal(b.root.dataset.soileThemeReady, 'true');
  assert.match(b.button.attrs['aria-label'], /светлую/);
  b.button.onclick(); await flush();
  assert.equal(b.selected, 'light'); assert.equal(b.store.get('soile.theme.v1'), 'light');
  assert.match(b.button.attrs['aria-label'], /тёмную/);
  assert.equal(b.button.focused, true);
  b.button.onclick(); await flush(); assert.equal(b.selected, 'dark'); b.unmount();
});
test('saved choice survives page mount and ordinary rerender does not open menu', async () => {
  const b = browser({saved: 'light'}); await flush(); assert.equal(b.selected, 'light');
  const before = b.menuClicks; b.remount(); await flush();
  assert.equal(b.menuClicks, before); assert.equal(b.selected, 'light'); b.unmount();
});
test('native theme rerender during a pending switch reuses one controller', async () => {
  const b = browser(); await flush();
  const button = b.button;
  button.onclick(); b.reinvoke(); await flush();
  assert.equal(b.selected, 'light'); assert.equal(b.button, button);
  const count = b.menuClicks; b.reinvoke(); await flush(); assert.equal(b.menuClicks, count);
  assert.equal(Object.keys(b.listeners).length, 3); b.unmount();
});

test('ambient is inert, singleton on theme rerender, pauses in hidden tabs and cleans up', async () => {
  const b = browser(); await flush();
  const layer = b.nodes.get('soile-ambient');
  assert.equal(layer.attrs['aria-hidden'], 'true'); assert.equal(layer.attrs.inert, '');
  b.reinvoke(); assert.equal(b.nodes.get('soile-ambient'), layer);
  b.document.hidden = true; b.listeners.visibilitychange();
  assert.equal(b.root.dataset.soilePageHidden, 'true');
  b.document.hidden = false; b.listeners.visibilitychange();
  assert.equal(b.root.dataset.soilePageHidden, undefined);
  b.unmount(); assert.equal(b.nodes.has('soile-ambient'), false);
});
test('invalid or inaccessible storage falls back to dark, toggle still works', async () => {
  for (const config of [{saved: 'garbage'}, {blocked: true}]) {
    const b = browser(config); await flush(); assert.equal(b.selected, 'dark');
    b.button.onclick(); await flush(); assert.equal(b.selected, 'light'); b.unmount();
  }
});
test('other tabs and native menu choices update the same preference', async () => {
  const b = browser(); await flush();
  b.listeners.storage({key: 'soile.theme.v1', newValue: 'light'}); await flush();
  assert.equal(b.selected, 'light');
  b.listeners.click({target: {closest: selector => selector.includes('theme-Dark')}});
  assert.equal(b.root.dataset.soileTheme, 'dark'); assert.equal(b.store.get('soile.theme.v1'), 'dark');
  b.unmount(); assert.equal(Object.keys(b.listeners).length, 0);
});

test('avatar boot restores theme before markup; only parent theme events are accepted', () => {
  const callbacks = {}, root = {dataset: {}}, parent = {};
  const sandbox = vm.createContext({document: {documentElement: root}, localStorage: {getItem: () => 'dark'},
    window: {parent, addEventListener: (key, fn) => callbacks[key] = fn}});
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../avatar_frontend/theme.js'), 'utf8'), sandbox);
  assert.equal(root.dataset.theme, 'dark');
  const data = {type: 'streamlit:render', theme: {backgroundColor: '#F5F7F8'}};
  callbacks.message({source: {}, data}); assert.equal(root.dataset.theme, 'dark');
  callbacks.message({source: parent, data}); assert.equal(root.dataset.theme, 'light');
  callbacks.storage({key: 'soile.theme.v1', newValue: 'dark'}); assert.equal(root.dataset.theme, 'dark');
});
