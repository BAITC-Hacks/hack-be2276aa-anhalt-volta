/* Run in <head>, before CSS/markup: never flash a light avatar for a dark user. */
(function () {
  function apply(value) { document.documentElement.dataset.theme = value === 'light' ? 'light' : 'dark'; }
  try { apply(localStorage.getItem('soile.theme.v1')); } catch { apply('dark'); }
  window.addEventListener('storage', event => {
    if (event.key === 'soile.theme.v1') apply(event.newValue);
  });
  window.addEventListener('message', event => {
    if (event.source !== window.parent || event.data?.type !== 'streamlit:render') return;
    const theme = event.data.theme;
    if (!theme) return;
    // The v1 public theme payload contains CSS colors, not a stable theme name.
    const hex = theme.backgroundColor?.replace('#', '');
    if (!/^[a-f\d]{6}$/i.test(hex || '')) return;
    const channels = [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16));
    apply(channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722 > 128 ? 'light' : 'dark');
  });
})();
