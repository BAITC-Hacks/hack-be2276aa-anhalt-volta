/* Rendering lives for the lifetime of the component, independently of Streamlit reruns. */
'use strict';
const {shapes, validateCues, cueAt, estimateCues, AvatarState} = AvatarCore;
const $ = id => document.getElementById(id);
const state = new AvatarState(), audio = $('audio');
const behavior = new AvatarBehavior.Behavior();
const react = name => behavior.react(name, performance.now() / 1000);
let lastReactionId = null, previousActivity = 'idle';
behavior.greet(performance.now() / 1000);
const synth = window.speechSynthesis;
let args = {}, lastReplyId = null, lastAudioId = null, resetId = null;
let cues = [], cueMode = 'amplitude', objectURL = null;
let context, analyser, samples, utterance, ttsCues = [], ttsOrigin = 0;
let generation = 0, queue = [], queueActive = false, pendingSpeech = false;
let previousTime = 0;
let yaw = 0, pitch = 0, roll = 0, mouth = [...shapes.X], lastState = '';
let manualPose = [0, 0, 0];
let manualUntil = 0, manualState = 'idle';
const layers = [...document.querySelectorAll('[data-depth]')];
const eyes = [...document.querySelectorAll('.eye')], pupils = [...document.querySelectorAll('.pupil')];
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
$('motion').checked = !reduced.matches;
function notice(text) { $('notice').textContent = text; }
function send(type, payload = {}) {
  if (window.parent !== window) window.parent.postMessage({isStreamlitMessage: true, type, ...payload}, '*');
}
function resize() { send('streamlit:setFrameHeight', {height: Math.ceil(document.querySelector('main').getBoundingClientRect().height) + 4}); }
new ResizeObserver(resize).observe(document.querySelector('main'));

function stop() {
  generation++;
  queue = []; queueActive = false; pendingSpeech = false;
  utterance = null; ttsCues = [];
  if (synth) synth.cancel();
  audio.pause();
  state.stop(); manualUntil = 0; behavior.clear();
}
function releaseURL() {
  if (objectURL) URL.revokeObjectURL(objectURL);
  objectURL = null;
}
function loadAudio(src, timeline = [], mode = 'visemes') {
  audio.src = src; cues = validateCues(timeline); cueMode = mode;
  audio.load();
  notice(cueMode === 'visemes' ? 'Visemes: рот следует таймкодам аудио.' : 'Упрощённый режим: рот по громкости. Для артикуляции добавьте visemes JSON.');
}
async function ensureAnalyser() {
  if (!context) {
    context = new (window.AudioContext || window.webkitAudioContext)();
    analyser = context.createAnalyser(); analyser.fftSize = 512;
    context.createMediaElementSource(audio).connect(analyser);
    analyser.connect(context.destination);
    samples = new Uint8Array(analyser.fftSize);
  }
  if (context.state === 'suspended') await context.resume();
}
audio.addEventListener('play', async () => {
  if (utterance || pendingSpeech) {
    generation++; utterance = null; pendingSpeech = false;
    synth?.cancel();
  }
  try { await ensureAnalyser(); }
  catch (_) { notice('Аудио играет; анализ громкости недоступен. Используйте visemes JSON.'); }
});
audio.addEventListener('playing', () => state.playback(true));
audio.addEventListener('pause', () => state.playback(false));
audio.addEventListener('waiting', () => state.playback(false));
audio.addEventListener('ended', () => { state.playback(false); if (queueActive) playNext(); });
audio.addEventListener('error', () => {
  if (!audio.getAttribute('src')) return;
  stop(); react('fallback'); notice('Не удалось декодировать аудио. Попробуйте другой WAV/MP3.');
});
async function playNext() {
  if (!queue.length) { queueActive = false; state.generationEnded(); return; }
  const item = queue.shift(); queueActive = true;
  releaseURL(); loadAudio(item.src, item.cues, 'visemes');
  try { await audio.play(); }
  catch (_) { queueActive = false; state.playback(false); notice('Нажмите ▶ в аудиоплеере, чтобы разрешить звук.'); }
}

function voices() {
  if (!synth) { $('speak').disabled = true; notice('В этом браузере нет TTS; используйте WAV/MP3.'); return; }
  const previous = $('voice').value, list = synth.getVoices();
  $('voice').replaceChildren();
  const automatic = document.createElement('option'); automatic.value = ''; automatic.textContent = 'Автоматический голос · RU / KK';
  $('voice').append(automatic);
  for (const voice of list) {
    const option = document.createElement('option'); option.value = voice.voiceURI;
    option.textContent = `${voice.name} · ${voice.lang}`; $('voice').append(option);
  }
  if (list.some(v => v.voiceURI === previous)) $('voice').value = previous;
}
voices(); synth?.addEventListener('voiceschanged', voices);
function speak(text, language = 'ru') {
  if (!synth || !text.trim()) return;
  stop(); const token = generation;
  const u = new SpeechSynthesisUtterance(text.trim().slice(0, 2000));
  const available = synth.getVoices();
  u.lang = language === 'kk' ? 'kk-KZ' : 'ru-RU';
  const selected = available.find(v => v.voiceURI === $('voice').value) || available.find(v => v.lang.toLowerCase().startsWith(u.lang.slice(0, 2)));
  if (selected) { u.voice = selected; u.lang = selected.lang; }
  utterance = u; pendingSpeech = true;
  u.onstart = () => {
    if (token !== generation) return;
    pendingSpeech = false; state.playback(true); ttsOrigin = performance.now() / 1000;
    ttsCues = estimateCues(u.text, u.text.length / 13);
    notice('Браузерный TTS: приблизительная артикуляция по тексту; точные фонемы недоступны.');
  };
  u.onboundary = e => {
    if (token !== generation || e.name !== 'word') return;
    const tail = u.text.slice(e.charIndex), word = tail.match(/^\S+/u)?.[0] || '';
    ttsOrigin = performance.now() / 1000;
    ttsCues = estimateCues(word, Math.max(.12, word.length / 13));
  };
  const finish = () => {
    if (token !== generation) return;
    pendingSpeech = false; utterance = null; ttsCues = []; state.playback(false); state.generationEnded();
  };
  u.onend = () => { finish(); if (token === generation) notice('Готово. Возвращаюсь к idle.'); };
  u.onerror = () => { finish(); if (token === generation) react('fallback'); if (token === generation) notice('TTS недоступен. Выберите установленный голос или загрузите аудио.'); };
  u.onpause = () => { if (token === generation) state.playback(false); };
  u.onresume = () => { if (token === generation) state.playback(true); };
  synth.speak(u);
}
$('speak').onclick = () => speak($('text').value, args.language);
$('reply').onclick = () => { if (args.reply) { $('text').value = args.reply; speak(args.reply, args.language); } };
$('reply').disabled = true;
$('demo').onclick = async () => {
  stop(); const token = generation;
  try {
    const response = await fetch('demo.json');
    if (!response.ok) throw Error('missing demo');
    const timeline = validateCues(await response.json());
    if (token !== generation) return;
    releaseURL(); loadAudio('demo.wav', timeline, 'visemes');
    $('avatar-controls').open = true;
    $('audio-controls').open = true;
    await ensureAnalyser();
    if (token !== generation) return;
    await audio.play();
  } catch (_) { if (token === generation) notice('Нажмите ▶ в аудиоплеере. Если демо отсутствует, загрузите свой WAV/MP3.'); }
};
$('stop').onclick = () => { stop(); notice('Остановлено. Idle-анимация продолжается.'); };
for (const name of ['idle', 'listening', 'thinking']) $(name).onclick = () => {
  stop(); manualState = name; manualUntil = performance.now() + 5000;
  state.setActivity(name); notice(name === 'idle' ? 'Idle: готов к разговору.' : 'Демонстрация состояния на 5 секунд; микрофон не включается.');
};
for (const value of Object.keys(shapes)) {
  const option = document.createElement('option'); option.value = value; option.textContent = value;
  $('shape').append(option);
}
$('file').onchange = () => {
  const file = $('file').files[0]; if (!file) return;
  if (file.size > 20 * 1024 * 1024) { notice('Максимальный размер аудио — 20 МБ.'); return; }
  stop(); releaseURL(); $('cues').value = '';
  objectURL = URL.createObjectURL(file); loadAudio(objectURL, [], 'amplitude');
};
$('cues').onchange = async () => {
  const file = $('cues').files[0]; if (!file) return;
  if (file.size > 5 * 1024 * 1024) { notice('JSON должен быть не больше 5 МБ.'); return; }
  try {
    const next = validateCues(JSON.parse(await file.text()));
    cues = next; cueMode = 'visemes'; notice(`Загружено ${cues.length} visemes; таймер — позиция аудиоплеера.`);
  } catch (error) { notice(error.message); }
};

let pointerX = 0, pointerY = 0;
$('stage').onpointermove = e => {
  const rect = $('stage').getBoundingClientRect();
  pointerX = (e.clientX - rect.left) / rect.width * 2 - 1;
  pointerY = (e.clientY - rect.top) / rect.height * 2 - 1;
};
$('stage').onpointerleave = () => { pointerX = pointerY = 0; };
function frame(ms) {
  if (document.hidden) { previousTime = ms / 1000; requestAnimationFrame(frame); return; }
  const t = ms / 1000, dt = Math.min(.05, Math.max(0, t - previousTime)); previousTime = t;
  const smooth = 1 - Math.exp(-dt * 8), motion = $('motion').checked && !reduced.matches;
  if (manualUntil && ms > manualUntil) { manualUntil = 0; state.setActivity(args.state || 'idle'); }
  const mood = state.value;
  const pose = behavior.update(t, dt, mood, motion, [pointerX, pointerY]);
  const sliders = [+$('yaw').value * 22, +$('pitch').value * 12, +$('roll').value * 10];
  manualPose = manualPose.map((v, i) => v + (sliders[i] - v) * smooth);
  [yaw, pitch, roll] = [pose.yaw + manualPose[0], pose.pitch + manualPose[1], pose.roll + manualPose[2]];
  // Pivot at the neck; the shoulders and shadow no longer rotate with the face.
  $('head').setAttribute('transform', `translate(${pose.headX + yaw * .65} ${pose.headY + pitch * .7}) translate(200 315) rotate(${roll}) scale(${(1 + pose.lean * .006) * Math.cos(yaw * Math.PI / 180)} ${1 + pose.lean * .006}) translate(-200 -315)`);
  $('body').setAttribute('transform', `translate(0 ${-pose.breath}) translate(200 404) scale(1 ${1 + pose.breath * .004}) translate(-200 -404)`);
  $('hair-front').setAttribute('transform', `rotate(${pose.hair} 200 140)`);
  $('hair-back').setAttribute('transform', `rotate(${pose.hair * .5} 200 180)`);
  for (const layer of layers) {
    const depth = +layer.dataset.depth;
    layer.setAttribute('transform', `translate(${yaw * depth / 45} ${-pitch * depth / 45})`);
  }
  for (const eye of eyes) eye.style.transform = `scaleY(${pose.blink * (1 - Math.max(0, pose.smile) * .035)})`;
  for (const pupil of pupils) pupil.setAttribute('transform', `translate(${pose.eyes[0]} ${pose.eyes[1]})`);
  $('brows').setAttribute('d', `M125 ${183 + pose.brow}Q149 ${169 + pose.brow} 174 ${182 + pose.brow - pose.asymmetry}M224 ${181 + pose.brow - pose.asymmetry}Q249 ${168 + pose.brow} 274 ${183 + pose.brow}`);
  $('smile').setAttribute('d', `M-24 ${-pose.smile * 2}Q0 ${3 + pose.smile * 4} 24 ${-pose.smile * 2}`);
  $('stage').dataset.reaction = pose.reaction || '';
  let target = shapes.X;
  if ($('shape').value !== 'auto') target = shapes[$('shape').value];
  else if (state.audioPlaying) {
    if (utterance) target = shapes[cueAt(ttsCues, t - ttsOrigin)];
    else if (cueMode === 'visemes') target = shapes[cueAt(cues, audio.currentTime)];
    else if (analyser) {
      analyser.getByteTimeDomainData(samples);
      let sum = 0; for (const sample of samples) sum += ((sample - 128) / 128) ** 2;
      const level = Math.max(0, Math.min(1, (Math.sqrt(sum / samples.length) - .012) * 9));
      target = [24 + level * 3, 2 + level * 23, .6 * level, .5 * level];
    }
  }
  const blend = 1 - Math.exp(-dt * 24);
  mouth = mouth.map((v, i) => v + (target[i] - v) * blend);
  // Curved corners affect both the actual opening and lips, not a line drawn below them.
  const corner = -pose.smile * 3 * Math.max(0, 1 - mouth[1] / 12);
  const contour = (w, h) => `M${-w} ${corner}Q0 ${-h * 2} ${w} ${corner}Q0 ${h * 2} ${-w} ${corner}Z`;
  $('mouthMask').setAttribute('d', contour(mouth[0], mouth[1]));
  $('lip').setAttribute('d', contour(mouth[0] + 2.5, mouth[1] + 2));
  $('teeth').setAttribute('y', -mouth[1] - 12); $('teeth').style.opacity = mouth[2];
  $('tongue').setAttribute('cy', mouth[1] * .85); $('tongue').style.opacity = mouth[3];
  $('smile').style.opacity = Math.max(0, 1 - mouth[1] / 5);
  const displayState = pose.reaction ? `${mood} · ${pose.reaction}` : mood;
  if (lastState !== displayState) { lastState = displayState; $('state').textContent = `● ${displayState}`; $('stage').dataset.state = mood; }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// Stable key keeps this component mounted. Repeated render events never replay a reply.
window.addEventListener('message', e => {
  if (e.source !== window.parent || e.data?.type !== 'streamlit:render') return;
  args = e.data.args || {};
  if (resetId !== null && resetId !== args.reset_id) {
    stop(); releaseURL(); audio.removeAttribute('src'); audio.load();
    cues = []; lastAudioId = null; lastReplyId = null;
  }
  resetId = args.reset_id;
  const activity = ['idle', 'listening', 'thinking'].includes(args.state) ? args.state : 'idle';
  if (activity !== previousActivity && activity !== 'idle') react('acknowledgement');
  previousActivity = activity;
  if (!manualUntil) state.setActivity(activity);
  $('reply').disabled = !args.reply;
  if (args.audio && args.audio.id !== lastAudioId) {
    stop(); releaseURL(); lastAudioId = args.audio.id;
    loadAudio(args.audio.src, args.audio.cues, args.audio.mode);
    $('avatar-controls').open = true;
    $('audio-controls').open = true;
  }
  if (args.reply_id && args.reply_id !== lastReplyId) {
    lastReplyId = args.reply_id; $('text').value = args.reply || '';
    if ($('autoplay').checked && args.reply) speak(args.reply, args.language);
  }
  if (args.reaction_id && args.reaction_id !== lastReactionId) {
    lastReactionId = args.reaction_id;
    if (Object.hasOwn(AvatarBehavior.reactions, args.reaction)) react(args.reaction);
  }
  resize();
});
// Adapter seam for a future TTS stream: complete encoded chunks + local cue times.
// Must be called in this frame. Tokens ending never stop queued audio.
window.avatar = {
  setActivity: value => {
    if (value !== state.activity && value !== 'idle') react('acknowledgement');
    state.setActivity(value);
  },
  react,
  getReaction: () => behavior.reaction?.name || null,
  generationEnded: () => state.generationEnded(),
  enqueueAudio: chunk => {
    if (!chunk || typeof chunk.src !== 'string' || !/^(blob:|data:audio\/)/.test(chunk.src)) throw Error('Expected local audio URL');
    const item = {src: chunk.src, cues: validateCues(chunk.cues)};
    if (queue.length >= 64) throw Error('Audio queue full: apply provider backpressure');
    if (utterance || pendingSpeech) stop();
    queue.push(item); if (!queueActive) { audio.pause(); playNext(); }
  }, stop, speak,
  getState: () => state.value
};
window.addEventListener('pagehide', () => { stop(); releaseURL(); context?.close(); });
send('streamlit:componentReady', {apiVersion: 1}); resize();
