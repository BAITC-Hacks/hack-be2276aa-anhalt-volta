/* Small, deterministic-testable behavior mixer. No DOM, audio or provider dependencies. */
(function (root) {
  'use strict';
  const poses = {
    idle: {yaw: 0, pitch: 0, roll: 0, gazeX: 0, gazeY: 0, brow: 0, smile: .2, focus: 1, lean: 0},
    listening: {yaw: 0, pitch: -1, roll: -2.5, gazeX: 0, gazeY: 0, brow: -2, smile: .3, focus: .12, lean: 2},
    thinking: {yaw: 3.2, pitch: -1, roll: 1.8, gazeX: 3, gazeY: -1.8, brow: 1.5, smile: 0, focus: .22, lean: 0},
    speaking: {yaw: 0, pitch: 0, roll: 0, gazeX: 0, gazeY: 0, brow: -.7, smile: .4, focus: .5, lean: .6}
  };
  const reactions = {
    greeting: {duration: 2, priority: 1, smile: .8, brow: -.8, pitch: -1, nod: .6},
    acknowledgement: {duration: .35, priority: 2, smile: .3, nod: 2},
    success: {duration: .75, priority: 3, smile: .9, brow: -1, nod: 1.6},
    unsure: {duration: 1.6, priority: 4, roll: 2.5, gazeX: -2, brow: -.6, asymmetry: 2, smile: -.1},
    fallback: {duration: 1.8, priority: 5, roll: -2.5, gazeX: 2, pitch: .6, brow: -.8, smile: .1, asymmetry: 1.5}
  };
  const aliases = {confused: 'unsure', error: 'fallback', welcome: 'greeting', acknowledgment: 'acknowledgement'};
  class Behavior {
    constructor(random = Math.random) {
      this.random = random; this.pose = {...poses.idle, asymmetry: 0};
      this.reaction = null; this.lastBase = 'idle'; this.greeted = false;
      this.blinkAt = 1.5 + random() * 2; this.blinkStart = -10; this.blinkDuration = .18;
      this.doubleBlink = false; this.gazeAt = 0; this.gaze = [0, 0]; this.eye = [0, 0];
      this.shiftAt = 0; this.shift = [0, 0, 0]; this.headShift = [0, 0, 0];
      this.hairLag = 0; this.releaseAt = -1; this.endNodAt = -10; this.speechAt = -10;
    }
    greet(t) { if (!this.greeted) { this.greeted = true; this.react('greeting', t); } }
    clear() { this.reaction = null; this.releaseAt = -1; this.endNodAt = -10; }
    react(name, t) {
      name = Object.hasOwn(aliases, name) ? aliases[name] : name;
      if (!Object.hasOwn(reactions, name)) throw Error('Invalid reaction');
      const config = reactions[name];
      if (this.reaction && t < this.reaction.end && reactions[this.reaction.name].priority > config.priority) return false;
      this.reaction = {name, start: t, end: t + config.duration}; return true;
    }
    update(t, dt, base, motion = true, pointer = [0, 0]) {
      dt = Math.max(0, Math.min(.05, dt));
      if (this.lastBase !== 'speaking' && base === 'speaking') {
        this.speechAt = t; this.releaseAt = -1; this.endNodAt = -10;
        this.shiftAt = t;
        this.gaze = [0, 0]; this.gazeAt = t + 1.5;
      }
      if (this.lastBase === 'speaking' && base !== 'speaking') {
        this.releaseAt = t + .22;
        if (this.random() < .65) this.blinkAt = this.releaseAt;
        else this.endNodAt = this.releaseAt;
      }
      this.lastBase = base;
      if (this.reaction && t >= this.reaction.end) this.reaction = null;
      const active = this.reaction, config = active ? reactions[active.name] : {};
      const phase = active ? (t - active.start) / config.duration : 0;
      const weight = active ? Math.sin(Math.PI * Math.max(0, Math.min(1, phase))) ** 2 : 0;
      const visualBase = t < this.releaseAt ? 'speaking' : active?.name === 'acknowledgement' && base === 'thinking' ? 'listening' : base;
      const target = {...(poses[visualBase] || poses.idle), asymmetry: 0};
      for (const key of ['yaw', 'pitch', 'roll', 'gazeX', 'brow', 'smile', 'asymmetry']) target[key] += (config[key] || 0) * weight;
      const nod = (config.nod || 0) * weight;
      const endPhase = (t - this.endNodAt) / .45;
      target.pitch += nod + (endPhase >= 0 && endPhase <= 1 ? Math.sin(endPhase * Math.PI) * 1.2 : 0);
      const speechAccent = base === 'speaking' ? Math.max(0, 1 - (t - this.speechAt) / .4) : 0;
      target.brow -= speechAccent * 1.5;
      const blend = 1 - Math.exp(-dt * (base === 'speaking' || active ? 12 : 7));
      for (const key of Object.keys(this.pose)) this.pose[key] += (target[key] - this.pose[key]) * blend;
      if (t >= this.gazeAt) {
        const positions = [[0, 0], [-3.2, .5], [3.2, -.5], [0, 1.7], [-2, -1.2]];
        this.gaze = this.gaze.some(v => v !== 0) ? [0, 0] : positions[1 + Math.floor(this.random() * 4)];
        this.gazeAt = t + 2 + this.random() * 3.5;
      }
      const p = this.pose;
      const eyeTarget = [Math.max(-3.8, Math.min(3.8, p.gazeX + this.gaze[0] * p.focus + pointer[0] * p.focus)),
        Math.max(-2.2, Math.min(2.2, p.gazeY + this.gaze[1] * p.focus + pointer[1] * p.focus * .6))];
      this.eye = this.eye.map((v, i) => v + (eyeTarget[i] - v) * (1 - Math.exp(-dt * 12)));
      if (t >= this.blinkAt) {
        this.blinkStart = t;
        this.blinkDuration = this.random() < .12 ? .24 : .12 + this.random() * .06;
        const second = !this.doubleBlink && this.random() < .12;
        this.doubleBlink = second;
        this.blinkAt = second ? t + this.blinkDuration + .12 : t + (base === 'thinking' ? 3.5 : 2.5) + this.random() * 3.5;
      }
      const blinkPhase = Math.max(0, Math.min(1, (t - this.blinkStart) / this.blinkDuration));
      const amplitude = motion ? p.focus : 0;
      const speaking = base === 'speaking' && motion;
      if (t >= this.shiftAt) {
        this.shift = [this.random() - .5, this.random() - .5, this.random() - .5];
        this.shiftAt = t + (speaking ? .55 + this.random() * 1.1 : 2 + this.random() * 3);
      }
      this.headShift = this.headShift.map((v, i) => v + (this.shift[i] - v) * (1 - Math.exp(-dt * 5)));
      const headRoll = motion ? Math.max(-3.6, Math.min(3.6, p.roll + Math.sin(t * .43) * 1.1 * amplitude + this.headShift[2] * (speaking ? 1.2 : .4))) : 0;
      this.hairLag += (headRoll - this.hairLag) * (1 - Math.exp(-dt * 4));
      return {...p,
        yaw: motion ? p.yaw + Math.sin(t * .37) * 1.2 * amplitude + pointer[0] * 2 * amplitude + this.headShift[0] * (speaking ? 1.5 : .5) : 0,
        pitch: motion ? p.pitch + Math.sin(t * .61) * .55 * amplitude + this.headShift[1] * (speaking ? 1.4 : .3) : 0,
        roll: headRoll,
        headX: motion ? Math.sin(t * .53) * 1.3 * amplitude : 0,
        headY: motion ? Math.sin(t * .71) * .8 * amplitude : 0,
        hair: motion ? Math.max(-1.2, Math.min(1.2, (this.hairLag - headRoll) * .8)) : 0,
        brow: p.brow + (speaking ? this.headShift[1] * 1.5 : 0),
        breath: motion ? Math.sin(t * 1.35) * 1.6 : 0,
        lean: motion ? p.lean : 0,
        eyes: motion ? this.eye : [0, 0],
        blink: 1 - .97 * Math.sin(blinkPhase * Math.PI),
        reaction: active?.name || null
      };
    }
  }
  const api = {Behavior, poses, reactions};
  if (typeof module !== 'undefined') module.exports = api;
  else root.AvatarBehavior = api;
})(globalThis);
