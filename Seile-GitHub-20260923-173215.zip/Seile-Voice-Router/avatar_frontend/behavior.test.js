const {test} = require('node:test');
const assert = require('node:assert/strict');
const {Behavior} = require('./behavior.js');

test('reactions obey priority, expire to current base, and greeting only runs once', () => {
  const b = new Behavior(() => .5);
  b.greet(0); assert.equal(b.reaction.name, 'greeting');
  b.react('fallback', .1);
  assert.equal(b.react('success', .2), false);
  assert.equal(b.update(.5, .016, 'speaking').reaction, 'fallback');
  assert.equal(b.update(3, .016, 'listening').reaction, null);
  b.greet(4); assert.equal(b.reaction, null);
  assert.throws(() => b.react('invalid', 5));
});

test('pose and gaze blend instead of snapping; all motion remains bounded over a long session', () => {
  let seed = 12;
  const b = new Behavior(() => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32));
  const first = b.update(0, .016, 'thinking');
  assert.ok(first.gazeX > 0 && first.gazeX < 1);
  for (let i = 1; i < 18000; i++) {
    const base = ['idle', 'thinking', 'listening', 'speaking'][Math.floor(i / 180) % 4];
    if (i % 137 === 0) b.react('unsure', i / 60);
    const p = b.update(i / 60, 1 / 60, base);
    assert.ok(Math.abs(p.yaw) < 4 && Math.abs(p.pitch) < 3 && Math.abs(p.roll) < 4);
    assert.ok(p.blink >= .029 && p.blink <= 1);
    assert.ok(p.eyes.every(v => Number.isFinite(v) && Math.abs(v) < 4));
  }
});

test('blink supports double and slow blinks, plus a blink after speech', () => {
  const b = new Behavior(() => 0);
  b.update(2, .016, 'speaking');
  assert.equal(b.blinkDuration, .24);
  assert.equal(b.doubleBlink, true);
  assert.ok(Math.abs(b.blinkAt - 2.36) < 1e-9);
  b.update(2.41, .016, 'speaking');
  assert.equal(b.doubleBlink, false);
  b.update(3, .016, 'idle');
  assert.equal(b.blinkAt, 3.22);
});

test('reduced motion suppresses continuous motion but preserves real blinking', () => {
  const b = new Behavior(() => .5); b.react('greeting', 0);
  const p = b.update(.5, .05, 'speaking', false, [1, 1]);
  assert.equal(p.breath, 0); assert.ok(p.blink > .99);
  assert.deepEqual(p.eyes, [0, 0]);
  assert.equal(p.yaw, 0); assert.equal(p.pitch, 0); assert.equal(p.roll, 0);
  b.update(3, .016, 'idle', false);
  b.update(4, .016, 'idle', false);
  const blink = b.update(4 + b.blinkDuration / 2, .016, 'idle', false);
  assert.ok(blink.blink < .05);
});

test('listening and thinking have visibly distinct poses and speaking refocuses within 350ms', () => {
  const b = new Behavior(() => .5);
  let p;
  for (let i = 0; i < 90; i++) p = b.update(i / 60, 1 / 60, 'listening');
  assert.ok(p.roll < -2 && p.brow < -1.8 && Math.abs(p.eyes[0]) < .5);
  for (let i = 90; i < 180; i++) p = b.update(i / 60, 1 / 60, 'thinking');
  assert.ok(p.yaw > 2.5 && p.roll > 1.4 && p.eyes[0] > 2.5 && p.eyes[1] < -1.3);
  for (let i = 180; i <= 201; i++) p = b.update(i / 60, 1 / 60, 'speaking');
  // Refocused pose still includes the intended sub-degree speaking micro-sway.
  assert.ok(Math.abs(p.eyes[0]) < .4 && Math.abs(p.roll) < .75);
  b.update(4, 1 / 60, 'idle');
  assert.equal(b.releaseAt, 4.22);
});

test('speaking micro motion varies its targets rather than repeating a sinusoidal loop', () => {
  let n = 0;
  const b = new Behavior(() => (n++ % 10) / 10);
  const targets = new Set();
  for (let i = 0; i < 600; i++) {
    b.update(i / 60, 1 / 60, 'speaking');
    targets.add(JSON.stringify(b.shift));
  }
  assert.ok(targets.size > 3);
});
