"""Per-browser themes. Never mutate Streamlit's process-global configuration."""
from pathlib import Path

import streamlit as st
from streamlit.components.v2 import component

_assets = Path(__file__).parent / 'theme_frontend'


def render_theme_switch():
    """Render the optional theme layer without making it a runtime dependency."""
    if not _assets.is_dir():
        st.markdown(
            '<style>:root{color-scheme:dark} .stApp{background:#0b1018}</style>',
            unsafe_allow_html=True,
        )
        return
    css = '\n'.join((_assets / name).read_text(encoding='utf-8')
                    for name in ('theme.css', 'ambient.css', 'layout.css'))
    st.html(f'<style>{css}</style>')
    _switch = component('soile_theme', js=(_assets / 'switch.js').read_text(encoding='utf-8'),
                        isolate_styles=False)
    _switch(key='soile_theme', height=0,
            data={'ambient': (_assets / 'ambient.html').read_text(encoding='utf-8')})
