# Sөile — голосовой роутер для Saqta Insurance

Проект HackAlem AI, трек Halyk Bank, кейс «Voice Router». Sөile принимает
русскую, казахскую и смешанную речь, выбирает страховой сценарий и показывает
супервизору объяснимый путь решения. Все данные клиентов в репозитории —
синтетические.

![Интерфейс](docs/screenshot.png)

## Возможности

- единый FastAPI backend с OpenAI-роутером, правилами fast path и fallback;
- текстовый и голосовой ввод через `/turn` и `/voice_turn`;
- STT/TTS через OpenAI с понятным переключением на текст при ошибке;
- сессии, подтверждения необратимых действий, pending topics и trace;
- Streamlit-интерфейс с панелью супервизора, темой и 2.5D-аватаром;
- amplitude-анимация аватара работает без Rhubarb; Rhubarb/FFmpeg опциональны.

Последний сохранённый live-прогон на 104 репликах дал 97.1% primary accuracy.
История улучшений: **93.3% → 95.2% → 94.2% → 97.1%**.

## Запуск

Нужен Python 3.10+. Из корня проекта:

```bash
cp .env.example .env
# впишите OPENAI_API_KEY в корневой .env
python3 run.py
```

Windows:

```bat
copy .env.example .env
py -3 run.py
```

Запускатель создаёт `.venv`, устанавливает `requirements.txt`, проверяет порты
8000 и 8501 и запускает оба процесса с отключённым запросом email Streamlit.

- интерфейс: http://127.0.0.1:8501
- API и Swagger: http://127.0.0.1:8000/docs

Оболочки `bash run.sh` и `run.cmd` вызывают тот же `run.py`. Другие порты:

```bash
PORT=8001 STREAMLIT_PORT=8502 python3 run.py
```

Если ключа нет или он недействителен, интерфейс покажет ошибку; текстовый ввод
и локальный режим-резерв останутся доступны.

## Интерфейс и аватар

Основной UI находится в [`ui/app.py`](ui/app.py). Он общается только с API:
создаёт `/session`, отправляет `/turn` или `/voice_turn`, получает `/tts` и
читает `/session/{id}/trace`. По умолчанию используется OpenAI backend.

Панель супервизора показывает transcript, название и ID сценария, confidence,
reasoning, alternatives, action, router mode, pending topics и STT/LLM/
executor/TTS/total timings. Быстрые примеры берутся из
[`voice_router_dataset/dialogs_sample.json`](voice_router_dataset/dialogs_sample.json).

Аватар включён по умолчанию. Его можно отключить без изменения кода:

```bash
AVATAR_ENABLED=0 python3 run.py
```

Без Rhubarb аудио из `/tts` запускает amplitude-анимацию. Точный phonetic
lip-sync включается только при наличии Rhubarb и, для MP3, FFmpeg. Подробности:
[`docs/AVATAR.md`](docs/AVATAR.md). Описание темы — в [`docs/THEME.md`](docs/THEME.md).

## Проверка

Демо-диалог:

```bash
python3 scripts/demo_dialog.py
```

Evaluation без платных запросов выполняется только с тестовыми заглушками;
живой прогон с OpenAI запускается явно:

```bash
./.venv/bin/python scripts/eval_router.py --workers 8
```

Тесты:

```bash
pytest
```

## Архитектура

```mermaid
flowchart LR
    B["Браузер / Streamlit"] --> T["POST /turn"]
    B --> V["POST /voice_turn"]
    V --> S["STT OpenAI"]
    T --> R["backend/llm_router.py"]
    S --> R
    R --> F{"fast_path_eligible и уверенность правил ≥ 0.8?"}
    F -->|да| FP["Быстрый путь rules"]
    F -->|нет| L["LLM Responses API"]
    L -->|ошибка или timeout| FB["Rules fallback"]
    FP --> E["Executor"]
    L --> E
    FB --> E
    E --> D["mock_backend + knowledge_base + actions"]
    D --> A["answer_text"]
    A --> Q["POST /tts"]
    Q --> B
    T -.-> X["session trace"]
    V -.-> X
    X --> P["GET /session/{id}/trace"]
```

В рабочем пути только один LLM-роутер — `backend/llm_router.py`. Каталог
сценариев, знания, действия, mock backend и eval-набор находятся в
`voice_router_dataset/` и не изменяются при объединении.

## API

| Метод | Endpoint | Назначение |
|---|---|---|
| POST | `/session` | создать сессию |
| POST | `/turn` | обработать текстовую реплику |
| POST | `/stt` | распознать webm/ogg/wav/mp3 |
| POST | `/tts` | получить mp3; `tts_ms` в заголовке |
| POST | `/voice_turn` | STT и обработка голосовой реплики |
| GET | `/session/{id}/trace` | получить решения сессии |

## Структура

```text
backend/               FastAPI, LLM-роутер, executor, STT/TTS
router/                правила участника 1
ui/                    единый Streamlit UI и аватар
tests/                 тесты backend/UI/avatar/theme
scripts/               eval, demo и benchmark
docs/                  eval_results, AVATAR, THEME, PITCH
voice_router_dataset/  исходный kit без изменений
README.md run.py       инструкция и кроссплатформенный запуск
run.sh run.cmd         оболочки запуска
requirements.txt       общие зависимости
```

## Ограничения

Сессии хранятся в памяти процесса и исчезают после перезапуска. Accuracy и
latency зависят от модели, сети и квоты OpenAI. Streaming STT/TTS,
распознавание эмоций и production-хранилище пока не реализованы.
